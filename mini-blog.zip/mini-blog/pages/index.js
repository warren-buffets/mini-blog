import { useState } from 'react';
import Link from 'next/link';
import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';

/**
 * Page d’accueil du blog.
 * Elle affiche la liste des articles avec leur titre et un extrait
 * et fournit un champ de recherche pour filtrer la liste.
 */
export default function Home({ posts }) {
  const [searchTerm, setSearchTerm] = useState('');

  // Filtrer les articles en fonction du terme de recherche
  const filteredPosts = posts.filter((post) => {
    const target = `${post.title} ${post.excerpt}`.toLowerCase();
    return target.includes(searchTerm.toLowerCase());
  });

  return (
    <div>
      <h1 className="text-4xl font-bold mb-6">Bienvenue sur mon blog</h1>
      <div className="mb-6">
        <input
          type="text"
          placeholder="Rechercher un article…"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="border rounded p-2 w-full max-w-md"
        />
      </div>
      {filteredPosts.length > 0 ? (
        <ul className="space-y-4">
          {filteredPosts.map(({ slug, title, excerpt }) => (
            <li key={slug} className="border rounded p-4 hover:bg-gray-50">
              <h2 className="text-2xl font-semibold">
                <Link href={`/posts/${slug}`}>
                  <a className="hover:underline text-blue-600">{title}</a>
                </Link>
              </h2>
              <p className="text-gray-600 mt-2">{excerpt}…</p>
              <Link href={`/posts/${slug}`}>
                <a className="text-blue-500 mt-2 inline-block">Lire la suite →</a>
              </Link>
            </li>
          ))}
        </ul>
      ) : (
        <p>Aucun article trouvé.</p>
      )}
    </div>
  );
}

/**
 * Récupère la liste des articles au moment de la génération statique.
 * Les articles sont stockés dans des fichiers Markdown dans le dossier `posts`.
 */
export async function getStaticProps() {
  const postsDirectory = path.join(process.cwd(), 'posts');
  const filenames = fs.readdirSync(postsDirectory);

  const posts = filenames
    .filter((file) => file.endsWith('.md'))
    .map((filename) => {
      const filePath = path.join(postsDirectory, filename);
      const fileContents = fs.readFileSync(filePath, 'utf8');
      const { data, content } = matter(fileContents);
      const slug = filename.replace(/\.md$/, '');
      return {
        slug,
        title: data.title || slug,
        excerpt: data.excerpt || content.slice(0, 150)
      };
    });

  return {
    props: {
      posts
    }
  };
}