/**
 * Page "À propos" simple.
 * Vous pouvez personnaliser le contenu de cette page pour présenter
 * l’auteur du blog ou expliquer le but du site.
 */
export default function About() {
  return (
    <div>
      <h1 className="text-4xl font-bold mb-4">À propos</h1>
      <p className="mb-2">
        Bienvenue sur mon mini blog personnel ! Je partage ici des articles sur
        la programmation, le développement web et mes projets personnels.
      </p>
      <p>
        Ce site est développé avec Next.js et les pages sont générées
        statiquement à partir de fichiers Markdown. N’hésitez pas à consulter
        le dépôt GitHub pour découvrir le code source.
      </p>
    </div>
  );
}