import fs from 'fs';
import path from 'path';
import matter from 'gray-matter';
import { remark } from 'remark';
import html from 'remark-html';
import Link from 'next/link';

/**
 * Page dynamique pour afficher un article individuel.
 * Le contenu Markdown est converti en HTML à la génération statique.
 */
export default function Post({ frontMatter, contentHtml }) {
  return (
    <article>
      <h1 className="text-4xl font-bold mb-4">{frontMatter.title}</h1>
      {frontMatter.date && (
        <p className="text-sm text-gray-500 mb-6">{frontMatter.date}</p>
      )}
      <div
        className="prose max-w-none"
        dangerouslySetInnerHTML={{ __html: contentHtml }}
      />
      <div className="mt-8">
        <Link href="/">
          <a className="text-blue-500">← Retour à l’accueil</a>
        </Link>
      </div>
    </article>
  );
}

/**
 * Récupère le contenu d’un article en fonction du slug.
 */
export async function getStaticProps({ params }) {
  const fullPath = path.join(process.cwd(), 'posts', `${params.slug}.md`);
  const fileContents = fs.readFileSync(fullPath, 'utf8');
  const { data, content } = matter(fileContents);
  const processedContent = await remark().use(html).process(content);
  const contentHtml = processedContent.toString();

  return {
    props: {
      frontMatter: data,
      contentHtml
    }
  };
}

/**
 * Indique à Next.js quelles pages doivent être générées statiquement.
 */
export async function getStaticPaths() {
  const postsDirectory = path.join(process.cwd(), 'posts');
  const filenames = fs.readdirSync(postsDirectory);
  const paths = filenames
    .filter((file) => file.endsWith('.md'))
    .map((filename) => ({
      params: {
        slug: filename.replace(/\.md$/, '')
      }
    }));
  return {
    paths,
    fallback: false
  };
}