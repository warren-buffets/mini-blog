---
title: "Mon premier article"
date: "2025-07-01"
excerpt: "Ceci est un extrait de mon premier article de blog."
---

Ceci est le contenu de **mon premier article** de blog en Markdown. Vous pouvez
utiliser du texte en **gras**, en *italique* et même créer des listes :

* Premier point
* Deuxième point
* Troisième point

Vous pouvez également ajouter des liens : [Next.js](https://nextjs.org/).